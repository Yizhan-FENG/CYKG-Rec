"""Evidence-gated learner profiling and constrained path recommendation."""


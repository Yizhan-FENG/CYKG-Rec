"""Build a deterministic, bounded EdNet KT2 attempt sample in Parquet."""

import argparse
import json
from pathlib import Path

import pyarrow as pa
import pyarrow.parquet as pq

from cykg_rec.data.adapters.ednet_kt2_attempts import iter_attempts


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--max-students", type=int, default=2000)
    args = parser.parse_args()
    workspace = Path(__file__).resolve().parents[1]
    raw = workspace / "data" / "raw" / "interaction_logs" / "EdNet"
    output_dir = workspace / "data" / "processed" / "interaction_logs" / "ednet_kt2_sample_v0_1"
    output_dir.mkdir(parents=True, exist_ok=True)
    target = output_dir / "attempts.parquet"
    writer = None; batch = []; total = 0
    for attempt in iter_attempts(raw / "EdNet-KT2.zip", raw / "EdNet-Contents.zip", args.max_students):
        batch.append(attempt)
        if len(batch) >= 10000:
            table = pa.Table.from_pylist(batch)
            writer = writer or pq.ParquetWriter(target, table.schema, compression="zstd")
            writer.write_table(table); total += len(batch); batch = []
    if batch:
        table = pa.Table.from_pylist(batch)
        writer = writer or pq.ParquetWriter(target, table.schema, compression="zstd")
        writer.write_table(table); total += len(batch)
    if writer:
        writer.close()
    report = {"dataset": "EdNet-KT2", "scope": "real_public", "students_requested": args.max_students, "attempts": total, "output": str(target)}
    (output_dir / "manifest.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False))

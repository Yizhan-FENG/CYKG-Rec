"""Extract auditable candidate knowledge-point seeds from curriculum standards."""

from __future__ import annotations

import hashlib
import json
import re
from pathlib import Path
from typing import Any

from pypdf import PdfReader


VERSION = "curriculum-seeds-v0.1"
HEADING = re.compile(
    r"^(?:第[一二三四五六七八九十百零〇\d]+[章节部分]|[一二三四五六七八九十]+、|\d+[.、])\s*(.{2,100})$"
)
GENERIC_PAGE_BOOKMARK = re.compile(r"(?:页面|page)[_\-\s]*\d+|^空白页面$", re.IGNORECASE)


def digest(path: Path) -> str:
    hasher = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            hasher.update(block)
    return hasher.hexdigest()


def infer_context(path: Path, root: Path) -> dict[str, str]:
    rel = path.relative_to(root)
    period = "高中" if "高中" in str(rel) else "义务教育"
    name = re.sub(r"^\d+\.", "", path.stem)
    name = re.sub(r"[（(][^）)]*[）)]", "", name)
    subject = re.sub(r"(普通高中|义务教育|课程标准|课程方案|年版|修订)", "", name)
    subject = re.sub(r"\s+", "", subject).strip("_- ")
    return {"stage_scope": period, "subject_hint": subject[:80] or "未标注"}


def is_subject_standard(path: Path) -> bool:
    """Course-plan PDFs are provenance sources, not subject knowledge seeds."""
    return "课程方案" not in path.name


def outline_candidates(reader: PdfReader) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []

    def walk(value: Any, depth: int = 0) -> None:
        if isinstance(value, list):
            for child in value:
                walk(child, depth + 1)
            return
        title = str(getattr(value, "title", value)).replace("\x00", "").strip()
        if not title or GENERIC_PAGE_BOOKMARK.search(title):
            return
        try:
            page = reader.get_destination_page_number(value) + 1
        except Exception:
            page = None
        items.append({"title": title[:300], "page": page, "depth": depth, "method": "pdf_outline"})

    try:
        walk(reader.outline)
    except Exception:
        return []
    return items


def early_heading_candidates(reader: PdfReader, pages: int = 20) -> list[dict[str, Any]]:
    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    for page_index, page in enumerate(reader.pages[:pages], start=1):
        try:
            text = page.extract_text(extraction_mode="layout") or ""
        except Exception:
            continue
        for raw in text.splitlines():
            title = " ".join(raw.split())
            if not HEADING.match(title) or title in seen:
                continue
            seen.add(title)
            items.append({"title": title[:300], "page": page_index, "depth": 0, "method": "early_page_heading"})
    return items


def write_jsonl(path: Path, values: list[dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for value in values:
            handle.write(json.dumps(value, ensure_ascii=False, sort_keys=True) + "\n")


def extract(root: Path, output: Path) -> dict[str, int | str]:
    output.mkdir(parents=True, exist_ok=True)
    documents: list[dict[str, Any]] = []
    seeds: list[dict[str, Any]] = []
    failures: list[dict[str, str]] = []
    for path in sorted(root.rglob("*.pdf")):
        doc_hash = digest(path)
        source_id = f"curriculum:{doc_hash}"
        context = infer_context(path, root)
        try:
            reader = PdfReader(path)
            candidates = outline_candidates(reader) or early_heading_candidates(reader)
            documents.append(
                {
                    "source_id": source_id,
                    "source_relpath": str(path.relative_to(root)),
                    "file_name": path.name,
                    "sha256": doc_hash,
                    "page_count": len(reader.pages),
                    "candidate_count": len(candidates),
                    "copyright_level": "official_standard_structure_only",
                    "pipeline_version": VERSION,
                    **context,
                }
            )
            for index, candidate in enumerate(candidates, start=1):
                if not is_subject_standard(path):
                    continue
                seeds.append(
                    {
                        "seed_id": f"{source_id}:seed:{index:04d}",
                        "source_id": source_id,
                        "label": candidate["title"],
                        "page": candidate["page"],
                        "depth": candidate["depth"],
                        "extraction_method": candidate["method"],
                        "review_status": "pending",
                        "pipeline_version": VERSION,
                        **context,
                    }
                )
        except Exception as exc:
            failures.append({"source_relpath": str(path.relative_to(root)), "error": str(exc)[:500]})
    write_jsonl(output / "curriculum_documents.jsonl", documents)
    write_jsonl(output / "knowledge_point_seeds.jsonl", seeds)
    write_jsonl(output / "parse_failures.jsonl", failures)
    report = {"version": VERSION, "documents": len(documents), "seeds": len(seeds), "failures": len(failures)}
    (output / "summary.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    return report

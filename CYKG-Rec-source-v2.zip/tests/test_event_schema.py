from cykg_rec.data.schema import CanonicalLearningEvent


def test_attempt_event_is_valid() -> None:
    event = CanonicalLearningEvent(
        dataset_id="synthetic_interactions_v0_1",
        dataset_scope="synthetic",
        learner_id_hash="synthetic_student_00001",
        event_order=0,
        event_type="attempt",
        question_id="item:syn:linear_equation:01",
        knowledge_point_ids=["syn:linear_equation"],
        correct=1,
        duration_sec=22.5,
    )
    assert event.correct == 1

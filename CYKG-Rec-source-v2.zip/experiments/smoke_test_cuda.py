"""Fail fast if the configured research environment cannot use the local GPU."""

from __future__ import annotations

import platform

import torch


def main() -> None:
    print(f"python={platform.python_version()}")
    print(f"torch={torch.__version__}")
    print(f"cuda_available={torch.cuda.is_available()}")
    if not torch.cuda.is_available():
        raise SystemExit("CUDA is unavailable. Do not install KT/GNN/VLM packages yet.")
    device = torch.device("cuda:0")
    props = torch.cuda.get_device_properties(device)
    sample = torch.randn((2048, 2048), device=device, dtype=torch.float16)
    result = sample @ sample.T
    torch.cuda.synchronize()
    print(f"gpu={props.name}")
    print(f"vram_gib={props.total_memory / 1024**3:.2f}")
    print(f"smoke_mean={result.float().mean().item():.6f}")
    print(f"peak_allocated_mib={torch.cuda.max_memory_allocated(device) / 1024**2:.1f}")


if __name__ == "__main__":
    main()

"""Compact models for evidence-gated educational recommendation."""


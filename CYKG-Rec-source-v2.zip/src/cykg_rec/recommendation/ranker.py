"""Evidence-gated learning-action ranking with counterfactual explanations."""

from __future__ import annotations

from typing import Any

from cykg_rec.recommendation.learner_path import MasteryEstimate


def readiness(kp: str, mastery: dict[str, MasteryEstimate], prerequisites: dict[str, set[str]], threshold: float) -> float:
    required = prerequisites.get(kp, set())
    if not required:
        return 1.0
    values = [mastery.get(parent, MasteryEstimate(parent, 0.5, 0.0, 0, 0.0)).mastery for parent in required]
    return sum(value >= threshold for value in values) / len(values)


def rank_learning_actions(
    mastery: dict[str, MasteryEstimate],
    prerequisites: dict[str, set[str]],
    threshold: float = 0.60,
) -> list[dict[str, Any]]:
    """Rank review-safe learning actions; score decomposition is retained."""
    ranked: list[dict[str, Any]] = []
    for kp, estimate in mastery.items():
        weak_need = 1.0 - estimate.mastery
        parent_readiness = readiness(kp, mastery, prerequisites, threshold)
        confidence_weight = 0.5 + 0.5 * estimate.confidence
        score = confidence_weight * (0.70 * weak_need + 0.30 * parent_readiness)
        blocked = parent_readiness < 1.0
        action = "review_prerequisites" if blocked else "practice_target"
        ranked.append(
            {
                "knowledge_point_id": kp,
                "recommended_action": action,
                "score": round(score, 6),
                "components": {
                    "weakness_need": round(weak_need, 6),
                    "prerequisite_readiness": round(parent_readiness, 6),
                    "evidence_confidence": round(estimate.confidence, 6),
                },
                "constraint": "approved_edges_only",
            }
        )
    return sorted(ranked, key=lambda item: item["score"], reverse=True)


def counterfactual_explanation(
    target_kp: str,
    mastery: dict[str, MasteryEstimate],
    prerequisites: dict[str, set[str]],
    threshold: float = 0.60,
) -> dict[str, Any]:
    """State the minimum prerequisite condition that changes a blocked action."""
    missing = []
    for parent in sorted(prerequisites.get(target_kp, set())):
        value = mastery.get(parent, MasteryEstimate(parent, 0.5, 0.0, 0, 0.0)).mastery
        if value < threshold:
            missing.append({"knowledge_point_id": parent, "current_mastery": round(value, 4), "required_mastery": threshold})
    if not missing:
        return {
            "target_kp": target_kp,
            "counterfactual": "no prerequisite constraint blocks target practice",
            "action_change": "practice_target remains allowed",
            "missing_prerequisites": [],
        }
    return {
        "target_kp": target_kp,
        "counterfactual": "if every listed prerequisite reaches the required mastery threshold",
        "action_change": "recommendation changes from review_prerequisites to practice_target",
        "missing_prerequisites": missing,
        "evidence_boundary": "uses approved prerequisite edges only",
    }

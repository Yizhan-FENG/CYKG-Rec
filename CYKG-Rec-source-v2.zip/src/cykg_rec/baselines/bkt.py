"""Small, auditable global-parameter Bayesian Knowledge Tracing baseline."""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass(frozen=True)
class BKTParameters:
    initial_mastery: float
    learn: float
    guess: float
    slip: float


def predict_and_update(mastery: float, response: int, params: BKTParameters) -> tuple[float, float]:
    probability = mastery * (1 - params.slip) + (1 - mastery) * params.guess
    if response:
        posterior = mastery * (1 - params.slip) / probability
    else:
        posterior = mastery * params.slip / (1 - probability)
    updated = posterior + (1 - posterior) * params.learn
    return float(probability), float(np.clip(updated, 1e-6, 1 - 1e-6))


def score_sequences(sequences: list[tuple[list[int], list[int]]], params: BKTParameters) -> tuple[np.ndarray, np.ndarray]:
    predictions: list[float] = []
    labels: list[int] = []
    for concepts, responses in sequences:
        states: dict[int, float] = {}
        for concept, response in zip(concepts, responses, strict=True):
            mastery = states.get(concept, params.initial_mastery)
            probability, states[concept] = predict_and_update(mastery, response, params)
            predictions.append(probability)
            labels.append(response)
    return np.asarray(labels, dtype=np.int8), np.asarray(predictions, dtype=np.float64)

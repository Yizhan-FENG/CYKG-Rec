import zipfile
from pathlib import Path

from cykg_rec.data.adapters.ednet import iter_ednet_events


def test_ednet_adapter_streams_response_and_explanation(tmp_path: Path) -> None:
    archive_path = tmp_path / "kt3.zip"
    with zipfile.ZipFile(archive_path, "w") as archive:
        rows = [
            ["timestamp", "action_type", "item_id", "source", "user_answer", "platform"],
            ["1552454260435", "enter", "e2575", "my_note", "", "mobile"],
            ["1552454264737", "respond", "q12", "sprint", "b", "mobile"],
        ]
        stream = "\n".join(",".join(row) for row in rows) + "\n"
        archive.writestr("KT3/u42.csv", stream)

    events = list(iter_ednet_events(archive_path, "ednet_kt3", max_students=1))
    assert events[0].event_type == "explanation_view"
    assert events[1].question_id == "q12"

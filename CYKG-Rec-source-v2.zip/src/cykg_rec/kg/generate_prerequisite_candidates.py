"""Generate evidence-gated prerequisite *candidates* from local course order.

The output separates weak sequencing evidence from confirmed instructional
prerequisites.  It is intentionally conservative and review-only.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from cykg_rec.kg.build_content_graph import iter_jsonl


VERSION = "prerequisite-candidates-v0.1"
ALLOWED_PRIORITIES = {"high", "medium"}


def best_mapping_by_section(records: list[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    best: dict[str, dict[str, Any]] = {}
    for record in records:
        if record.get("review_priority") not in ALLOWED_PRIORITIES or record.get("rank") != 1:
            continue
        current = best.get(record["section_id"])
        if current is None or record["semantic_similarity"] > current["semantic_similarity"]:
            best[record["section_id"]] = record
    return best


def generate(follow_edges: Path, mappings: Path, output: Path) -> dict[str, int | str]:
    mapping_records = list(iter_jsonl(mappings))
    best = best_mapping_by_section(mapping_records)
    emitted: list[dict[str, Any]] = []
    seen: set[tuple[str, str, str]] = set()
    for edge in iter_jsonl(follow_edges):
        if edge.get("relation") != "FOLLOWS":
            continue
        left, right = best.get(edge["source"]), best.get(edge["target"])
        if not left or not right or left["seed_id"] == right["seed_id"]:
            continue
        key = (left["seed_id"], right["seed_id"], left["evidence"]["section_source"])
        if key in seen:
            continue
        seen.add(key)
        score = round(min(float(left["semantic_similarity"]), float(right["semantic_similarity"])), 6)
        emitted.append(
            {
                "candidate_id": f"{left['seed_id']}::prerequisite_candidate::{right['seed_id']}",
                "source_seed_id": left["seed_id"],
                "target_seed_id": right["seed_id"],
                "source_label": left["seed_label"],
                "target_label": right["seed_label"],
                "relation": "PREREQUISITE_CANDIDATE",
                "candidate_score": score,
                "evidence": {
                    "type": "adjacent_textbook_order_plus_semantic_mapping",
                    "textbook_source_id": left["evidence"]["section_source"],
                    "left_section_id": left["section_id"],
                    "right_section_id": right["section_id"],
                    "left_mapping_priority": left["review_priority"],
                    "right_mapping_priority": right["review_priority"],
                },
                "review_status": "pending",
                "automatic_decision": "none",
                "warning": "Textbook adjacency is sequencing evidence, not proof of a prerequisite relation.",
                "pipeline_version": VERSION,
            }
        )
    pairs = {(item["source_seed_id"], item["target_seed_id"]) for item in emitted}
    reciprocal_count = 0
    for item in emitted:
        reverse = (item["target_seed_id"], item["source_seed_id"])
        if reverse in pairs:
            item["review_status"] = "requires_manual_resolution"
            item["conflict"] = "reciprocal_textbook_order"
            item["warning"] = "Reciprocal candidate detected; do not use this edge until a reviewer resolves the cycle."
            reciprocal_count += 1
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open("w", encoding="utf-8", newline="\n") as handle:
        for record in sorted(emitted, key=lambda item: item["candidate_score"], reverse=True):
            handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
    return {
        "version": VERSION,
        "candidates": len(emitted),
        "eligible_section_mappings": len(best),
        "reciprocal_candidates_requiring_manual_resolution": reciprocal_count,
    }

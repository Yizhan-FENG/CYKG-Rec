"""Build the auditable content layer of the Chuan-Yu K12 graph.

This stage deliberately emits only evidence-supported relations.  A textbook's
table-of-contents order is represented as ``FOLLOWS``; it is *not* silently
promoted to a pedagogical prerequisite relation.  Candidate prerequisites will
be proposed and teacher-reviewed in a later stage.
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any, Iterable


GRAPH_VERSION = "content-graph-v0.1"


def iter_jsonl(path: Path) -> Iterable[dict[str, Any]]:
    with path.open("r", encoding="utf-8") as handle:
        for line in handle:
            if line.strip():
                yield json.loads(line)


def write_jsonl(path: Path, records: Iterable[dict[str, Any]]) -> int:
    count = 0
    with path.open("w", encoding="utf-8", newline="\n") as handle:
        for record in records:
            handle.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
            count += 1
    return count


def build_content_graph(textbook_dir: Path, regional_dir: Path, output_dir: Path) -> dict[str, int | str]:
    output_dir.mkdir(parents=True, exist_ok=True)
    documents = list(iter_jsonl(textbook_dir / "textbook_documents.jsonl"))
    sections = list(iter_jsonl(textbook_dir / "textbook_sections.jsonl"))
    regional_lessons = list(iter_jsonl(regional_dir / "regional_lesson_nodes.jsonl"))

    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    for document in documents:
        nodes.append(
            {
                "id": document["source_id"],
                "type": "textbook",
                "label": document["file_name"],
                "stage": document.get("stage"),
                "subject": document.get("subject"),
                "publisher": document.get("publisher"),
                "copyright_level": document.get("copyright_level"),
                "evidence": {"source_relpath": document["source_relpath"], "sha256": document["sha256"]},
                "review_status": document.get("review_status", "auto"),
                "graph_version": GRAPH_VERSION,
            }
        )

    grouped_sections: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for section in sections:
        grouped_sections[section["source_id"]].append(section)
        nodes.append(
            {
                "id": section["section_id"],
                "type": "textbook_section",
                "label": section["title"],
                "stage": next((d.get("stage") for d in documents if d["source_id"] == section["source_id"]), None),
                "subject": next((d.get("subject") for d in documents if d["source_id"] == section["source_id"]), None),
                "page": section.get("page"),
                "depth": section.get("depth"),
                "evidence": {"source_id": section["source_id"], "section_index": section["section_index"]},
                "review_status": section.get("review_status", "auto"),
                "graph_version": GRAPH_VERSION,
            }
        )
        edges.append(
            {
                "source": section["source_id"],
                "target": section["section_id"],
                "relation": "CONTAINS",
                "confidence": 1.0,
                "evidence_type": "source_structure",
                "review_status": "auto",
                "graph_version": GRAPH_VERSION,
            }
        )

    for source_id, source_sections in grouped_sections.items():
        ordered = sorted(source_sections, key=lambda value: value["section_index"])
        for previous, following in zip(ordered, ordered[1:]):
            edges.append(
                {
                    "source": previous["section_id"],
                    "target": following["section_id"],
                    "relation": "FOLLOWS",
                    "confidence": 1.0,
                    "evidence_type": "textbook_order",
                    "review_status": "auto",
                    "graph_version": GRAPH_VERSION,
                }
            )

    for lesson in regional_lessons:
        nodes.append(
            {
                "id": lesson["node_id"],
                "type": "regional_lesson",
                "label": lesson["name"],
                "stage": lesson.get("stage"),
                "grade": lesson.get("grade"),
                "subject": lesson.get("subject"),
                "regional_scope": lesson.get("regional_scope"),
                "regional_type": lesson.get("regional_type"),
                "evidence": {"locator": lesson.get("evidence_locator")},
                "review_status": lesson.get("review_status", "auto"),
                "graph_version": GRAPH_VERSION,
            }
        )

    node_count = write_jsonl(output_dir / "nodes.jsonl", nodes)
    edge_count = write_jsonl(output_dir / "edges.jsonl", edges)
    manifest = {
        "graph_version": GRAPH_VERSION,
        "node_count": node_count,
        "edge_count": edge_count,
        "relations": {"CONTAINS": len(sections), "FOLLOWS": max(0, len(sections) - len(documents))},
        "regional_lesson_count": len(regional_lessons),
        "policy": "FOLLOWS is content order only; PREREQUISITE requires separate evidence and review.",
    }
    (output_dir / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    return manifest

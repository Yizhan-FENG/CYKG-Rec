from cykg_rec.recommendation.learner_path import MasteryEstimate
from cykg_rec.recommendation.ranker import counterfactual_explanation, rank_learning_actions


def test_blocked_target_explains_missing_prerequisite():
    mastery = {
        "a": MasteryEstimate("a", 0.3, 1.0, 8, 0.0),
        "b": MasteryEstimate("b", 0.2, 1.0, 8, 0.0),
    }
    edges = {"b": {"a"}}
    ranked = rank_learning_actions(mastery, edges)
    b = next(item for item in ranked if item["knowledge_point_id"] == "b")
    assert b["recommended_action"] == "review_prerequisites"
    assert counterfactual_explanation("b", mastery, edges)["missing_prerequisites"][0]["knowledge_point_id"] == "a"

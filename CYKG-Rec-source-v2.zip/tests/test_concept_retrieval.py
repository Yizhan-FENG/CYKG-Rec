from cykg_rec.kg.retrieve_concept_candidates import eligible_seed, normalized_subject


def test_noisy_policy_title_is_not_a_candidate_seed():
    assert not eligible_seed({"label": "一、修订工作的指导思想和基本原则"})


def test_subject_normalization():
    assert normalized_subject("生物学学科") == "生物学"

from cykg_rec.data.adapters.ednet_kt2_attempts import learner_hash


def test_ednet_learner_hash_is_stable_and_not_raw_id():
    assert learner_hash("533092") == learner_hash("533092")
    assert "533092" not in learner_hash("533092")

"""Interpretable learner profiling and safe prerequisite-path planning."""

from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from typing import Any, Iterable


@dataclass(frozen=True)
class MasteryEstimate:
    knowledge_point_id: str
    mastery: float
    confidence: float
    attempts: int
    hint_rate: float


def estimate_mastery(events: Iterable[dict[str, Any]], learner_id: str) -> dict[str, MasteryEstimate]:
    """Estimate per-KP mastery with a transparent Beta posterior.

    Hint usage contributes fractional negative evidence; it never overrides an
    observed correct/incorrect response.
    """
    stats: dict[str, dict[str, float]] = defaultdict(lambda: {"alpha": 1.0, "beta": 1.0, "attempts": 0.0, "hints": 0.0})
    for event in events:
        if event.get("learner_id_hash") != learner_id or event.get("correct") not in (0, 1):
            continue
        for kp in event.get("knowledge_point_ids", []):
            row = stats[kp]
            row["attempts"] += 1
            row["hints"] += float(event.get("hint_count", 0))
            if event["correct"] == 1:
                row["alpha"] += 1
            else:
                row["beta"] += 1
            row["beta"] += min(float(event.get("hint_count", 0)), 2.0) * 0.15
    result: dict[str, MasteryEstimate] = {}
    for kp, row in stats.items():
        total = row["alpha"] + row["beta"]
        result[kp] = MasteryEstimate(
            knowledge_point_id=kp,
            mastery=row["alpha"] / total,
            confidence=min(1.0, row["attempts"] / 8.0),
            attempts=int(row["attempts"]),
            hint_rate=row["hints"] / max(1.0, row["attempts"]),
        )
    return result


def approved_prerequisites(edges: Iterable[dict[str, Any]]) -> dict[str, set[str]]:
    """Return target -> required prerequisites, excluding unreviewed edges."""
    result: dict[str, set[str]] = defaultdict(set)
    for edge in edges:
        if edge.get("relation_type") == "requires" and edge.get("dataset_scope") == "synthetic":
            result[edge["source_node_id"]].add(edge["target_node_id"])
        elif edge.get("relation") == "PREREQUISITE" and edge.get("review_status") == "approved":
            result[edge["target_seed_id"]].add(edge["source_seed_id"])
    return result


def recommend_path(
    mastery: dict[str, MasteryEstimate],
    prerequisites: dict[str, set[str]],
    target_kp: str,
    mastery_threshold: float = 0.60,
) -> list[dict[str, Any]]:
    """Topologically order only unmet, evidence-approved prerequisites."""
    path: list[str] = []
    visiting: set[str] = set()
    visited: set[str] = set()

    def visit(kp: str) -> None:
        if kp in visited:
            return
        if kp in visiting:
            raise ValueError(f"approved prerequisite graph contains cycle at {kp}")
        visiting.add(kp)
        for prerequisite in sorted(prerequisites.get(kp, set())):
            estimate = mastery.get(prerequisite)
            if estimate is None or estimate.mastery < mastery_threshold:
                visit(prerequisite)
        visiting.remove(kp)
        visited.add(kp)
        estimate = mastery.get(kp)
        if kp == target_kp or estimate is None or estimate.mastery < mastery_threshold:
            path.append(kp)

    visit(target_kp)
    return [
        {
            "knowledge_point_id": kp,
            "estimated_mastery": None if kp not in mastery else round(mastery[kp].mastery, 4),
            "evidence_confidence": None if kp not in mastery else round(mastery[kp].confidence, 4),
            "reason": "target_weak_point" if kp == target_kp else "unmastered_approved_prerequisite",
            "constraint": "approved_edges_only",
        }
        for kp in path
    ]

from cykg_rec.recommendation.learner_path import approved_prerequisites, estimate_mastery, recommend_path


def test_path_requires_approved_or_synthetic_edges_only():
    events = [{"learner_id_hash": "s", "correct": 0, "knowledge_point_ids": ["b"], "hint_count": 0}]
    mastery = estimate_mastery(events, "s")
    edges = [
        {"source_node_id": "b", "target_node_id": "a", "relation_type": "requires", "dataset_scope": "synthetic"},
        {"source_seed_id": "x", "target_seed_id": "y", "relation": "PREREQUISITE", "review_status": "pending"},
    ]
    path = recommend_path(mastery, approved_prerequisites(edges), "b")
    assert [item["knowledge_point_id"] for item in path] == ["a", "b"]

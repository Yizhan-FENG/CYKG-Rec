from pathlib import Path

from cykg_rec.kg.extract_curriculum_seeds import GENERIC_PAGE_BOOKMARK, infer_context, is_subject_standard


def test_curriculum_context_distinguishes_high_school():
    root = Path("standards")
    path = root / "高中_2017_2020" / "普通高中数学课程标准.pdf"
    context = infer_context(path, root)
    assert context["stage_scope"] == "高中"
    assert "数学" in context["subject_hint"]


def test_generic_page_bookmark_is_rejected():
    assert GENERIC_PAGE_BOOKMARK.search("课程标准_页面_001")


def test_course_plan_is_not_a_subject_seed_source():
    assert not is_subject_standard(Path("普通高中课程方案（2020年修订）.pdf"))

from cykg_rec.kg.score_review_queue import priority


def test_review_priority_is_never_acceptance():
    assert priority(0.80, 1) == "high"
    assert priority(0.80, 2) == "medium"
    assert priority(0.50, 1) == "low"

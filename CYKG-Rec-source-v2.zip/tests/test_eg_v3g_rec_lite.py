import torch

from cykg_rec.models.eg_v3g_rec_lite import EGV3GRecLite


def test_model_produces_gated_logits():
    model = EGV3GRecLite(4, torch.tensor([[1, 2], [0, 1]]), dim=16)
    result = model(torch.tensor([[0, 1, 2]]), torch.tensor([[1, 0, 1]]), torch.tensor([3]), torch.tensor([0.5]))
    assert result["logit"].shape == (1,)
    assert 0.0 <= result["gate"].item() <= 1.0

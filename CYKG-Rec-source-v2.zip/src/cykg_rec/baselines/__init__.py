"""Reproducible baseline implementations."""

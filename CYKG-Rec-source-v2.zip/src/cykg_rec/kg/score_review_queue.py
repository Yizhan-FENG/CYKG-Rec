"""Prioritize, but never auto-accept, semantic mapping candidates."""

from __future__ import annotations

import json
from collections import Counter
from pathlib import Path


VERSION = "review-priority-v0.1"


def priority(score: float, rank: int) -> str:
    if rank == 1 and score >= 0.65:
        return "high"
    if rank <= 3 and score >= 0.55:
        return "medium"
    return "low"


def score_queue(source: Path, target: Path, summary_path: Path) -> dict[str, int | str]:
    target.parent.mkdir(parents=True, exist_ok=True)
    counts: Counter[str] = Counter()
    total = 0
    with source.open("r", encoding="utf-8") as reader, target.open("w", encoding="utf-8", newline="\n") as writer:
        for line in reader:
            record = json.loads(line)
            level = priority(float(record["semantic_similarity"]), int(record["rank"]))
            record["review_priority"] = level
            record["automatic_decision"] = "none"
            record["review_instructions"] = "确认概念粒度、版本一致性与教学语义；不得仅凭相似度接受。"
            record["priority_version"] = VERSION
            writer.write(json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n")
            counts[level] += 1
            total += 1
    summary: dict[str, int | str] = {"version": VERSION, "total": total, **dict(counts)}
    summary_path.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    return summary

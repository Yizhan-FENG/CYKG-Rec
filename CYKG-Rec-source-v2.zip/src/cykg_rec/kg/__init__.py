"""Version-aware educational knowledge graph primitives."""


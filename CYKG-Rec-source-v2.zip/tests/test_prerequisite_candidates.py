from cykg_rec.kg.generate_prerequisite_candidates import best_mapping_by_section


def test_only_top_one_non_low_mappings_can_seed_prerequisites():
    records = [
        {"section_id": "a", "rank": 1, "review_priority": "high", "semantic_similarity": 0.8},
        {"section_id": "b", "rank": 2, "review_priority": "high", "semantic_similarity": 0.9},
        {"section_id": "c", "rank": 1, "review_priority": "low", "semantic_similarity": 0.9},
    ]
    assert set(best_mapping_by_section(records)) == {"a"}

from cykg_rec.kg.build_content_graph import build_content_graph


def test_content_graph_keeps_order_distinct_from_prerequisite(tmp_path):
    textbooks = tmp_path / "textbooks"
    regional = tmp_path / "regional"
    output = tmp_path / "graph"
    textbooks.mkdir()
    regional.mkdir()
    (textbooks / "textbook_documents.jsonl").write_text(
        '{"source_id":"book:1","file_name":"book.pdf","source_relpath":"book.pdf","sha256":"x"}\n', encoding="utf-8"
    )
    (textbooks / "textbook_sections.jsonl").write_text(
        '{"section_id":"s:1","source_id":"book:1","section_index":1,"title":"A"}\n'
        '{"section_id":"s:2","source_id":"book:1","section_index":2,"title":"B"}\n', encoding="utf-8"
    )
    (regional / "regional_lesson_nodes.jsonl").write_text(
        '{"node_id":"r:1","name":"四川课程","regional_scope":"sichuan"}\n', encoding="utf-8"
    )
    result = build_content_graph(textbooks, regional, output)
    assert result["node_count"] == 4
    assert '"relation": "FOLLOWS"' in (output / "edges.jsonl").read_text(encoding="utf-8")
    assert "PREREQUISITE" not in (output / "edges.jsonl").read_text(encoding="utf-8")

"""Create leakage-safe learner-level splits for the EdNet KT2 sample."""

import hashlib
import json
from pathlib import Path

import pandas as pd


def split_bucket(learner_hash: str) -> str:
    bucket = int(hashlib.sha256(f"cykg-split-v1:{learner_hash}".encode()).hexdigest()[:8], 16) % 100
    return "train" if bucket < 80 else "valid" if bucket < 90 else "test"


if __name__ == "__main__":
    workspace = Path(__file__).resolve().parents[1]
    root = workspace / "data" / "processed" / "interaction_logs" / "ednet_kt2_sample_v0_1"
    data = pd.read_parquet(root / "attempts.parquet")
    data["split"] = data["learner_id_hash"].map(split_bucket)
    stats = {"split_version": "learner_hash_v1", "rows": {}, "students": {}}
    for split, group in data.groupby("split"):
        group.drop(columns="split").to_parquet(root / f"{split}.parquet", index=False, compression="zstd")
        stats["rows"][split] = len(group)
        stats["students"][split] = int(group["learner_id_hash"].nunique())
    (root / "split_manifest.json").write_text(json.dumps(stats, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(stats, ensure_ascii=False))

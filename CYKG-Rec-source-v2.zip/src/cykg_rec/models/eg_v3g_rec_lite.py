"""EG-V3G-Rec-Lite: a compact evidence-gated temporal/graph KT model.

This is the reproducible baseline implementation, not a claim that unreviewed
curriculum candidates are factual prerequisite edges.
"""

from __future__ import annotations

import torch
from torch import nn


class EGV3GRecLite(nn.Module):
    def __init__(self, num_kps: int, edge_index: torch.Tensor, dim: int = 128) -> None:
        super().__init__()
        self.num_kps = num_kps
        self.register_buffer("edge_index", edge_index.long())  # target, prerequisite
        self.kp_embedding = nn.Embedding(num_kps, dim)
        self.interaction_embedding = nn.Embedding(num_kps * 2, dim)
        self.temporal_encoder = nn.GRU(dim, dim, batch_first=True)
        self.graph_linear = nn.Linear(dim, dim)
        self.temporal_head = nn.Linear(dim * 2, 1)
        self.graph_head = nn.Linear(dim * 2, 1)
        self.gate = nn.Sequential(nn.Linear(dim + 1, dim // 2), nn.ReLU(), nn.Linear(dim // 2, 1), nn.Sigmoid())

    def graph_embeddings(self) -> torch.Tensor:
        base = self.kp_embedding.weight
        if self.edge_index.numel() == 0:
            return torch.tanh(self.graph_linear(base))
        target, prerequisite = self.edge_index
        aggregate = torch.zeros_like(base)
        aggregate.index_add_(0, target, base[prerequisite])
        degree = torch.zeros(self.num_kps, device=base.device, dtype=base.dtype)
        degree.index_add_(0, target, torch.ones_like(target, dtype=base.dtype))
        return torch.tanh(self.graph_linear(base + aggregate / degree.clamp_min(1).unsqueeze(1)))

    def forward(self, history_kp: torch.Tensor, history_correct: torch.Tensor, target_kp: torch.Tensor, evidence_confidence: torch.Tensor) -> dict[str, torch.Tensor]:
        interaction_ids = history_kp * 2 + history_correct.long()
        _, hidden = self.temporal_encoder(self.interaction_embedding(interaction_ids))
        state = hidden[-1]
        graph = self.graph_embeddings()
        target_base = self.kp_embedding(target_kp)
        target_graph = graph[target_kp]
        temporal_logit = self.temporal_head(torch.cat([state, target_base], dim=1)).squeeze(1)
        graph_logit = self.graph_head(torch.cat([state, target_graph], dim=1)).squeeze(1)
        gate = self.gate(torch.cat([state, evidence_confidence.unsqueeze(1)], dim=1)).squeeze(1)
        logit = gate * temporal_logit + (1.0 - gate) * graph_logit
        return {"logit": logit, "gate": gate, "temporal_logit": temporal_logit, "graph_logit": graph_logit}

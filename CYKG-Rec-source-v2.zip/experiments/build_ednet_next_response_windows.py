"""Create one canonical next-response protocol for all EdNet KT models."""
import json
from pathlib import Path
import pandas as pd

if __name__ == '__main__':
    workspace=Path(__file__).resolve().parents[1]; root=workspace/'data'/'processed'/'interaction_logs'/'ednet_kt2_sample_v0_1'; out=root/'next_response_windows_v1';out.mkdir(parents=True,exist_ok=True)
    report={'protocol':'last_20_responses_predict_next_response','splits':{}}
    for split in ('train','valid','test'):
        data=pd.read_parquet(root/f'{split}.parquet').sort_values(['learner_id_hash','event_time','event_order']); rows=[]
        for learner,g in data.groupby('learner_id_hash'):
            seq=[(x[0],int(y)) for x,y in zip(g.knowledge_point_ids,g.correct) if len(x)]
            for i in range(1,len(seq)):
                h=seq[max(0,i-20):i]; rows.append({'learner_id_hash':learner,'history_kps':[x[0] for x in h],'history_correct':[x[1] for x in h],'target_kp':seq[i][0],'target_correct':seq[i][1],'history_length':len(h)})
        frame=pd.DataFrame(rows); frame.to_parquet(out/f'{split}.parquet',index=False,compression='zstd'); report['splits'][split]={'windows':len(frame),'students':int(frame.learner_id_hash.nunique())}
    (out/'manifest.json').write_text(json.dumps(report,indent=2),encoding='utf8');print(json.dumps(report,indent=2))

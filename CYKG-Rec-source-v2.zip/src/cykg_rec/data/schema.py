"""Strict data contracts shared by every interaction-log adapter."""

from __future__ import annotations

from datetime import datetime
from typing import Literal

from pydantic import BaseModel, Field, field_validator


EventType = Literal[
    "attempt",
    "enter",
    "respond",
    "submit",
    "hint_request",
    "resource_view",
    "explanation_view",
    "lecture_view",
    "chat_self_report",
]
DatasetScope = Literal["real_public", "synthetic", "local_authorized"]


class DatasetProvenance(BaseModel):
    dataset_id: str
    source_url: str
    license: str
    dataset_scope: DatasetScope
    regional_scope: Literal["sichuan", "chongqing", "chengyu", "national", "external"]
    notes: str = ""


class CanonicalLearningEvent(BaseModel):
    """One privacy-preserving, time-ordered learning event.

    ``correct`` is intentionally nullable because viewing an explanation or a
    video is evidence of engagement, not a response outcome.
    """

    dataset_id: str
    dataset_scope: DatasetScope
    learner_id_hash: str
    event_time: datetime | None = None
    event_order: int = Field(ge=0)
    event_type: EventType
    item_id: str | None = None
    question_id: str | None = None
    knowledge_point_ids: list[str] = Field(default_factory=list)
    correct: int | None = Field(default=None, ge=0, le=1)
    duration_sec: float | None = Field(default=None, ge=0)
    hint_count: int = Field(default=0, ge=0)
    response_option: str | None = None
    resource_id: str | None = None
    source_context: str | None = None
    self_report: str | None = None
    evidence_confidence: float | None = Field(default=None, ge=0, le=1)

    @field_validator("learner_id_hash")
    @classmethod
    def forbid_empty_learner_id(cls, value: str) -> str:
        if not value.strip():
            raise ValueError("learner_id_hash cannot be empty")
        return value

"""Region-aware post-ranking policy that keeps knowledge and availability distinct."""
from __future__ import annotations
from typing import Any, Iterable


def apply_regional_policy(options: Iterable[dict[str, Any]], region: str) -> list[dict[str, Any]]:
    """Return learning options with policy evidence attached, never alter mastery facts."""
    result: list[dict[str, Any]] = []
    for option in options:
        kind = option.get("option_type")
        if kind == "sichuan_local_learning_objective" and region != "sichuan":
            continue
        row = dict(option)
        if kind == "national_concept_retrieval_candidate":
            catalog = row.get("regional_policy", {}).get("chongqing_compatible_catalog_entry_ids", [])
            row["regional_support_materials"] = catalog if region == "chongqing" else []
            row["learning_item_available"] = True
        else:
            row["learning_item_available"] = True
        row["region_applied"] = region
        result.append(row)
    return result

"""Create a review queue linking textbook sections to curriculum seed titles.

Semantic similarity is evidence for a *candidate mapping*, never an automatic
knowledge-point edge.  Every output item remains ``pending`` for review.
"""

from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from typing import Any

import numpy as np

from cykg_rec.kg.build_content_graph import iter_jsonl


VERSION = "concept-retrieval-v0.1"
NOISY_TERMS = ("修订工作", "指导思想", "基本原则", "坚持正确", "课程方案")


def normalized_subject(value: str | None) -> str:
    return (value or "").replace("学科", "").strip()


def eligible_seed(seed: dict[str, Any]) -> bool:
    label = seed["label"].strip()
    return len(label) >= 3 and not any(term in label for term in NOISY_TERMS)


def retrieve(
    section_path: Path,
    document_path: Path,
    seed_path: Path,
    model_dir: Path,
    output_path: Path,
    top_k: int = 5,
    batch_size: int = 16,
    device: str = "cuda",
) -> dict[str, int | str]:
    from sentence_transformers import SentenceTransformer

    documents = {record["source_id"]: record for record in iter_jsonl(document_path)}
    groups: dict[tuple[str | None, str], list[dict[str, Any]]] = defaultdict(list)
    for seed in iter_jsonl(seed_path):
        if eligible_seed(seed):
            groups[(seed.get("stage_scope"), normalized_subject(seed.get("subject_hint")))].append(seed)

    model = SentenceTransformer(str(model_dir), device=device)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    emitted = 0
    skipped = 0
    with output_path.open("w", encoding="utf-8", newline="\n") as handle:
        for section in iter_jsonl(section_path):
            document = documents.get(section["source_id"], {})
            stage = document.get("stage")
            stage_scope = "高中" if stage == "高中" else "义务教育"
            candidates = groups.get((stage_scope, normalized_subject(document.get("subject"))), [])
            title = section.get("title", "").strip()
            if not candidates or len(title) < 2:
                skipped += 1
                continue
            query = model.encode([title], normalize_embeddings=True, convert_to_numpy=True, batch_size=1)[0]
            corpus = model.encode(
                [candidate["label"] for candidate in candidates],
                normalize_embeddings=True,
                convert_to_numpy=True,
                batch_size=batch_size,
            )
            scores = np.asarray(corpus @ query)
            for rank, idx in enumerate(np.argsort(-scores)[:top_k], start=1):
                seed = candidates[int(idx)]
                item = {
                    "candidate_id": f"{section['section_id']}::maps_to::{seed['seed_id']}",
                    "section_id": section["section_id"],
                    "seed_id": seed["seed_id"],
                    "section_label": title,
                    "seed_label": seed["label"],
                    "stage": stage,
                    "subject": document.get("subject"),
                    "rank": rank,
                    "semantic_similarity": round(float(scores[int(idx)]), 6),
                    "proposed_relation": "MAPS_TO_CANDIDATE_KNOWLEDGE_POINT",
                    "review_status": "pending",
                    "evidence": {
                        "section_source": section["source_id"],
                        "seed_source": seed["source_id"],
                        "embedding_model": "BAAI/bge-m3",
                    },
                    "pipeline_version": VERSION,
                }
                handle.write(json.dumps(item, ensure_ascii=False, sort_keys=True) + "\n")
                emitted += 1
    return {"version": VERSION, "candidate_mappings": emitted, "skipped_sections": skipped}
